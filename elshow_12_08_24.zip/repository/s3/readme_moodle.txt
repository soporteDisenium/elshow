- S3.php -

Amazon S3 PHP Class

Cloned from https://github.com/tpyo/amazon-s3-php-class.git

https://github.com/tpyo/amazon-s3-php-class
http://undesigned.org.za/2007/10/22/amazon-s3-php-class

Local changes applied:
(verify on each upgrade of the library if they have been applied
upstream. Remove the local changes if so)

MDL-67031 php74 compliance. Change curly to square braces.
MDL-73523 php80 compliance. Deprecated openssl_free_key() use (https://github.com/tpyo/amazon-s3-php-class/issues/178)
MDL-77342 PHP 8.2 compliance. Add property $file in class S3Request.